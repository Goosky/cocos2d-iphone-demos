//
//  Chess.m
//  ChessDemo
//
//  Created by Podevor on 13-1-7.
//  Copyright 2013年 __MyCompanyName__. All rights reserved.
//

#import "Chess.h"
#import "CCBReader.h"
#import "SimpleAudioEngine.h"
#import "Player.h"

@implementation Chess

-(void) dealloc{
    [super dealloc];
    for (id obj in cards) {
        [obj release];
    }
    [cards release];
    for (id obj in chosenCards) {
        [obj release];
    }
    [chosenCards release];
    [delegate release];
}
#pragma mark - init all variables
-(void) didLoadFromCCB{
    cards = [NSMutableArray arrayWithCapacity:0];
    chosenCards = [NSMutableArray arrayWithCapacity:0];
    [cards addObject:card];
    [cards addObject:card1];
    [cards addObject:card2];
    [cards addObject:card3];
    [cards retain];
    [chosenCards retain];
    [self randomTag];
    isHeader = YES;
    //timer    
    remainderTimer = [NSTimer scheduledTimerWithTimeInterval:kGameStartRemainderTime target:self selector:@selector(startGame) userInfo:nil repeats:NO];
    //remainder label
    CGPoint remainderTimePos = remainderTime.position;
    [remainderTime removeFromParentAndCleanup:YES];
    remainderTime = [CCLabelTTF labelWithString:kRemainder fontName:@"Arial" fontSize:20];
    remainderTime.position = remainderTimePos;
    [self addChild:remainderTime];
    gameTime = 30;
    // init delegate
    delegate = (AppController*) [[UIApplication sharedApplication] delegate];
    //init player score
    score = 0;
}

#pragma mark - changeRemainderTimeLabel

-(void) reStart{    
    CCScene *scene = [CCBReader sceneWithNodeGraphFromFile:@"chess.ccbi"];
    [[CCDirector sharedDirector] replaceScene:scene];
}

-(void) startGame{
    [[SimpleAudioEngine sharedEngine] playBackgroundMusic:kBackground loop:YES];
    remainderTimer = [NSTimer scheduledTimerWithTimeInterval:kChangeTime target:self selector:@selector(changeRemainderTimeLabel) userInfo:nil repeats:YES];
}

-(void) changeRemainderTimeLabel{
    [remainderTime setString:[NSString stringWithFormat:@"%@%d",kRemainderInfo,gameTime]];
    if (gameTime == 0) {
        [remainderTimer invalidate];
        [remainderTime setString:kGameOver];
        self.isTouchEnabled = NO;
    }else{
        [[SimpleAudioEngine sharedEngine] playEffect:kClockEffect];
        gameTime--;        
    }
}

#pragma mark - random the card sprite tag

-(void) randomTag{
    //card list
    NSMutableArray *allCards = [NSMutableArray arrayWithCapacity:0];
    for (int cardIndex = 1; cardIndex <= kCardsCount; cardIndex++) {
        [allCards addObject:[self index:cardIndex]];
    }
    //tag list
    NSMutableArray *tags = [NSMutableArray arrayWithCapacity:0];
    for (int i = 0; i < cards.count/2; i++) {
        int index = arc4random()%allCards.count;
        [tags addObject:[allCards objectAtIndex:index]];
        [tags addObject:[allCards objectAtIndex:index]];
        [allCards removeObjectAtIndex:index];
    }
    //set tag for sprite
    for (CCSprite* sprite in cards) {
        int index  = arc4random()%tags.count;        
        sprite.tag = [[tags objectAtIndex:index] intValue];
        [tags removeObjectAtIndex:index];
    }
}

#pragma mark - rollover ,scale and change the spriteFrame

-(void)rolloverByIndex:(int) index { //play effect
    if (isHeader) {
        [[SimpleAudioEngine sharedEngine] playEffect:kClickEffect];
    }
    //get sprite by index
    CCSprite *sprite = [cards objectAtIndex:index];
    //package obj
    NSNumber *nIndex = [NSNumber numberWithInt:index];
    //one half rollover
    id oneHalfRollover = [CCScaleTo actionWithDuration:kHalfRolloverTime scaleX:kMidScaleX scaleY:kScaleY];
    id firstSeqAction = [CCSequence actions:oneHalfRollover,
                         [CCCallFuncND actionWithTarget:self selector:@selector(changeSprite:data:) data:nIndex], nil];
    [sprite runAction:firstSeqAction];
}


-(void) changeSprite:(id) sender data:(NSNumber*) nIndex{
    //format index
    int index = [nIndex intValue];    
    CCSprite *sprite = [cards objectAtIndex:index];
    //get old data
    int tag = sprite.tag;
    CGPoint oldPos = [sprite position];
    [sprite removeFromParentAndCleanup:YES];
    //new sprite by tag
    if (isHeader) {
        sprite = [CCSprite spriteWithFile:[NSString stringWithFormat:@"image%d.png",tag]];
    }else{
        sprite = [CCSprite spriteWithFile:kHeaderImageName];
    }
    sprite.tag = tag;
    sprite.position = oldPos;
    [sprite setScaleX:kMidScaleX];
    [self addChild:sprite];
    //another half rollover
    id anotherHalfRollover = [CCScaleTo actionWithDuration:kHalfRolloverTime scaleX:kScaleX scaleY:kScaleY];
    [sprite runAction:anotherHalfRollover];
    //replace sprite
    [cards replaceObjectAtIndex:index withObject:sprite];
}

#pragma mark - common 

- (CGRect)rectInPixels:(CCSprite*) sprite
{
	CGSize s = [[sprite texture] contentSizeInPixels];
    return CGRectMake(-s.width/2, -s.height/2, s.width, s.height);
}

-(NSNumber*) index:(int) index{
    return [NSNumber numberWithInt:index];
}

#pragma mark - dispatch touch event

-(BOOL) ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event{ 
    //CCLOG(@"begin");
    BOOL result = NO;
    result = [super ccTouchBegan:touch withEvent:event] && result;

    return result;
}

-(void) ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
   // CCLOG(@"move");
}

-(void) ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{    
    UITouch *touch = [touches anyObject];
    for (int index = 0; index < [cards count]; index++) {
        CGRect r = [self rectInPixels:[cards objectAtIndex:index]];
        CGPoint p = [[cards objectAtIndex:index] convertTouchToNodeSpaceAR:touch];
        if (CGRectContainsPoint(r, p)) {
            if (![chosenCards containsObject:[self index:index]]
                && [chosenCards count] <= 2) {
                isHeader = YES;
                //rollover card
                [self rolloverByIndex:index];
                //add chosen card
                [chosenCards addObject:[self index:index]];
            }
        }
    }
    //check the card is the same or not
    [self checkCard];
}


#pragma mark - check card is the same or not
-(void) checkCard{
    if ([chosenCards count] == 2) {
        self.isTouchEnabled = NO;
        int firstIndex = [[chosenCards objectAtIndex:0] intValue];
        int secondIndex = [[chosenCards objectAtIndex:1] intValue];
        CCSprite *firstChoose = [cards objectAtIndex:firstIndex];
        CCSprite *secondChoose = [cards objectAtIndex:secondIndex];
        if ( firstChoose.tag == secondChoose.tag) {
            //the same card
            [NSTimer scheduledTimerWithTimeInterval:kShowSameCardTime
                                             target:self selector:@selector(bangAnimation) userInfo:nil repeats:NO];
        }else{
            //not same
            [NSTimer scheduledTimerWithTimeInterval:kRolloverBckDelayTime
                                             target:self selector:@selector(rolloverBack) userInfo:nil repeats:NO];
        }
    }
}

-(void) bangAnimation{
    int firstIndex = [[chosenCards objectAtIndex:0] intValue];
    int secondIndex = [[chosenCards objectAtIndex:1] intValue];
    CCSprite *firstChoose = [cards objectAtIndex:firstIndex];
    CCSprite *secondChoose = [cards objectAtIndex:secondIndex];
    CCParticleSystem *firstBang = [CCParticleSystemQuad particleWithFile:kParticaleName];
    firstBang.position = firstChoose.position;
    // [firstChoose runAction:scale];
    [self addChild:firstBang z:0 tag:kFirstBang];
    CCParticleSystem *secondBang = [CCParticleSystemQuad particleWithFile:kParticaleName];
    secondBang.position = secondChoose.position;
    // [secondChoose runAction:scale];
    [self addChild:secondBang z:0 tag:kSecondBang];
    //clear
    [firstChoose removeFromParentAndCleanup:YES];
    [secondChoose removeFromParentAndCleanup:YES];
    [cards removeObjectAtIndex:[cards indexOfObject:firstChoose]];
    [cards removeObjectAtIndex:[cards indexOfObject:secondChoose]];
    //clear the choose list
    [chosenCards removeAllObjects];
    //clear the particles
    [NSTimer scheduledTimerWithTimeInterval:kClearPartileTime
                                     target:self selector:@selector(clearParticales) userInfo:nil repeats:NO];
}

-(void) clearParticales{
    id f = [self getChildByTag:kFirstBang];
    [f removeFromParentAndCleanup:YES];
    id s = [self getChildByTag:kSecondBang];
    [s removeFromParentAndCleanup:YES];
    //play effect    
    [[SimpleAudioEngine sharedEngine] playEffect:kClearEffect];
   
    //check win or not
    [self checkWon];
    [NSTimer scheduledTimerWithTimeInterval:kOpenTouchTime
                                     target:self selector:@selector(openTouch) userInfo:nil repeats:NO];
}


-(void) checkWon{
    if ([cards count] == 0) {
       // CCLOG(@"won");
        score = 123;
      //  [self pushData];
       // [self pullData];
      //  UIAlertView *view = [[UIAlertView alloc] initWithTitle:@"" message:@"额,爷们你赢了~" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"好~再来一次吧~", nil];
      //  [view show];
     //   [view release];
       // if (gameTime != 0) {
          //  [remainderTimer invalidate];
          //  self.isTouchEnabled = NO;
       // }
       // [NSTimer scheduledTimerWithTimeInterval:2.0f target:self selector:@selector(reStart) userInfo:nil repeats:NO];
        [self reStart];
    }
}

-(void) rolloverBack{
   // CCLOG(@"rolloverback");
    int firstIndex = [[chosenCards objectAtIndex:0] intValue];
    int secondIndex = [[chosenCards objectAtIndex:1] intValue];
    //rollover back
    isHeader = NO;
    [self rolloverByIndex:firstIndex];
    [self rolloverByIndex:secondIndex];
    //clear the choose list
    [chosenCards removeAllObjects];
    [NSTimer scheduledTimerWithTimeInterval:kOpenTouchTime
                                     target:self selector:@selector(openTouch) userInfo:nil repeats:NO];
}

-(void) openTouch{
    self.isTouchEnabled = YES;
}
/*
#pragma mark - push data to database ,pull data from database
-(void) pushData{
    CCLOG(@"push data");
    Player *player
    = (Player*) [NSEntityDescription insertNewObjectForEntityForName:kEntityName inManagedObjectContext:delegate.managedObjectContext];
    [player setUserName:@"朱丛启"];
    [player setUserScore:[NSNumber numberWithInt:score]];
    //push to sqlite
    NSError *error;
    BOOL isSaveSuccess = [delegate.managedObjectContext save:&error];
    
    if (!isSaveSuccess) {
        NSLog(@"Error: %@,%@",error,[error userInfo]);
    }else {
        NSLog(@"Save successful!");
    }
}

-(void) pullData{
    CCLOG(@"pull data");
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity
    = [NSEntityDescription entityForName:kEntityName inManagedObjectContext:delegate.managedObjectContext];
    [request setEntity:entity];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:kSortDesc ascending:NO];
    NSArray *sortDescriptions = [[NSArray alloc]initWithObjects:sortDescriptor, nil];
    [request setSortDescriptors:sortDescriptions];
    [sortDescriptions release];
    [sortDescriptor release];
    NSError *error = nil;
    NSMutableArray *mutableFetchResult
    = [[delegate.managedObjectContext executeFetchRequest:request error:&error] mutableCopy];
    if (mutableFetchResult == nil) {
        NSLog(@"Error: %@,%@",error,[error userInfo]);
    }
    
    for (Player *player in mutableFetchResult) {
        NSLog(@"name:%@---Score : %d",player.userName,player.userScore.intValue);
    }
    
    [mutableFetchResult release];
    [request release];
}*/
@end
