//
//  Player.m
//  ChessDemo
//
//  Created by Podevor on 13-1-10.
//
//

#import "Player.h"


@implementation Player

@dynamic userName;
@dynamic userScore;

@end
